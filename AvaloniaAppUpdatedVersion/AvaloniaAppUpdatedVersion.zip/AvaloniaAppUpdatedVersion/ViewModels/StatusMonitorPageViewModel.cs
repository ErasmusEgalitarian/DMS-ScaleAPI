﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AvaloniaAppUpdatedVersion.Data;

namespace AvaloniaAppUpdatedVersion.ViewModels
{
    public partial class StatusMonitorPageViewModel : PageViewModel
    {
        public StatusMonitorPageViewModel()
        {
            PageName = ApplicationPageNames.StatusMonitor;
        }
    }
}
