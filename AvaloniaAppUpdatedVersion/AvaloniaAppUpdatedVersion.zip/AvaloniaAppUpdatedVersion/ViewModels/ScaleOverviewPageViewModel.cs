﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.Input;
using AvaloniaAppUpdatedVersion.Templates;
using AvaloniaAppUpdatedVersion.Services;
using AvaloniaAppUpdatedVersion.Data;
using AvaloniaAppUpdatedVersion.Factories;

namespace AvaloniaAppUpdatedVersion.ViewModels
{
    public partial class ScaleOverviewPageViewModel : PageViewModel
    {
        private PageFactory _pageFactory;
        private PageViewModel _currentPage;

        public ScaleOverviewPageViewModel()
        {
            PageName = ApplicationPageNames.ScaleOverview;
        }
        [RelayCommand]
        private void ToScale1() => CurrentPage = _pageFactory.GetPageViewModel(ApplicationPageNames.Scale1);
    }
}
